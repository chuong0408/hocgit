<?php
const HOST = 'localhost';
const USERNAME = 'root';
const DATABASE = 'php1';
const PASSWORD = '';
define('USERNAME_EMAIL', 'chuongpdpk03971@gmail.com'); // thay bằng email của các bạn
define('PASSWORD_EMAIL', 'gbeflcupoqnbvzqe'); // thay bằng password của các bạn
?>
