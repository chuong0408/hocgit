<?php 
const HOST = 'localhost';
const USERNAME = 'root';
const DATABASE = 'php1';
const PASSWORD = '';
?>