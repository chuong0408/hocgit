<form action="process_search.php" method="get">
<div class="input-group">
  <input type="search" class="form-control rounded" placeholder="Nhập tên sản phẩm bạn muốn tìm kiếm" aria-label="Search" aria-describedby="search-addon" name="id" />
  <button type="submit" class="btn btn-outline-primary" data-mdb-ripple-init>search</button>
</div>
</form>