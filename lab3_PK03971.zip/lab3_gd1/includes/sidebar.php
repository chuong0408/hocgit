
<div class="col-sm-3">
    <ul class="list-group">
        <li class="list-group-item">
            <a class="btn btn-link" href="danhmuc.php">Danh Mục</a>
        </li>
        <li class="list-group-item">
            <a class="btn btn-link" href="thuonghieu.php">Thương Hiệu</a>
        </li>
        <li class="list-group-item">
            <a class="btn btn-link" href="sanpham.php">Sản phẩm</a>
        </li>
    </ul>
</div>